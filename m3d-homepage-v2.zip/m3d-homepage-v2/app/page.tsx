import Image from "next/image";

const tracks = [
  { title: "Lettre au ciel", subtitle: "À mon père", tag: "Émotion" },
  { title: "Missiles et cicatrices", subtitle: "Vécu · vérité · résilience", tag: "Drill" },
  { title: "Pars", subtitle: "Quand la porte reste ouverte", tag: "Trap" },
];

export default function Home() {
  return (
    <main>
      <section className="hero" id="accueil">
        <div className="hero-glow" />
        <nav className="nav">
          <a className="brand" href="#accueil">M3D<span>.</span></a>
          <div className="nav-links">
            <a href="#musique">Musique</a>
            <a href="#clips">Clips</a>
            <a href="#apropos">À propos</a>
            <a href="#contact">Contact</a>
          </div>
          <a className="nav-cta" href="#musique">Écouter</a>
        </nav>

        <div className="hero-grid">
          <div className="hero-copy">
            <p className="eyebrow">M3D · ARTISTE · GABÈS</p>
            <h1>
              J&apos;rap la vie,
              <span>pas l&apos;conte de fées.</span>
            </h1>
            <p className="hero-text">
              Des mots vrais. Des cicatrices. Des leçons de vie.
              Un univers sombre, humain et sans masque.
            </p>
            <div className="hero-actions">
              <a className="button button-red" href="#musique">Découvrir ma musique</a>
              <a className="button button-ghost" href="#apropos">Mon histoire <span>↓</span></a>
            </div>
            <div className="hero-signature">
              <span /> M3D, j&apos;rap la vie, pas l&apos;conte de fées.
            </div>
          </div>

          <div className="hero-art">
            <div className="art-frame">
              <Image
                src="/images/m3d-hero.png"
                alt="Univers visuel M3D"
                fill
                priority
                sizes="(max-width: 900px) 90vw, 52vw"
              />
            </div>
          </div>
        </div>

        <div className="scroll-note">SCROLL <span>↓</span></div>
      </section>

      <section className="section music-section" id="musique">
        <div className="section-heading">
          <div>
            <p className="section-number">01 · MUSIQUE</p>
            <h2>Mes morceaux<span>.</span></h2>
          </div>
          <p>Des histoires vécues, transformées en sons.</p>
        </div>

        <div className="track-grid">
          {tracks.map((track, index) => (
            <article className="track-card" key={track.title}>
              <div className="track-number">0{index + 1}</div>
              <div>
                <span className="track-tag">{track.tag}</span>
                <h3>{track.title}</h3>
                <p>{track.subtitle}</p>
              </div>
              <button className="play-button" aria-label={`Écouter ${track.title}`}>▶</button>
            </article>
          ))}
        </div>
      </section>

      <section className="visual-section" id="clips">
        <div className="visual-image">
          <Image
            src="/images/m3d-univers.jpg"
            alt="Univers sombre et rouge de M3D"
            fill
            sizes="(max-width: 900px) 100vw, 50vw"
          />
        </div>
        <div className="visual-copy">
          <p className="section-number">02 · CLIPS</p>
          <h2>Le son.<br /><span>L&apos;image.</span><br />L&apos;univers.</h2>
          <p>
            Chaque morceau possède son atmosphère. Noir, rouge, brut :
            l&apos;image prolonge les mots et donne une forme aux cicatrices.
          </p>
          <a className="text-link" href="#contact">Voir les prochains clips <span>↗</span></a>
        </div>
      </section>

      <section className="about-section" id="apropos">
        <div className="about-label">
          <p className="section-number">03 · À PROPOS</p>
        </div>
        <div className="about-copy">
          <h2>Pas un personnage.<br /><span>Une histoire.</span></h2>
          <p>
            M3D vient de Gabès. Son rap parle de ce qui reste quand les
            apparences disparaissent : la famille, les pertes, la loyauté,
            l&apos;amour, les erreurs et les leçons de la vie.
          </p>
          <p>
            Pas besoin de raconter une vie parfaite. Il suffit de raconter
            la vraie.
          </p>
        </div>
      </section>

      <section className="quote-section">
        <div className="quote-mark">“</div>
        <blockquote>
          J&apos;rap la vie,<br />
          pas l&apos;conte de fées.
        </blockquote>
        <p>— M3D</p>
      </section>

      <footer className="footer" id="contact">
        <div>
          <a className="brand footer-brand" href="#accueil">M3D<span>.</span></a>
          <p>Artiste · Gabès · Tunisie</p>
        </div>
        <div className="footer-links">
          <a href="#musique">Musique</a>
          <a href="#clips">Clips</a>
          <a href="#apropos">À propos</a>
          <a href="#contact">Contact</a>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} M3D. Tous droits réservés.</span>
          <span>M3D, j&apos;rap la vie, pas l&apos;conte de fées.</span>
        </div>
      </footer>
    </main>
  );
}
